package com.iiht.project.subham.ms1.iiht_ms1.config;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.project.subham.ms1.iiht_ms1.domain.model.ResponseMessage;
import com.iiht.project.subham.ms1.iiht_ms1.domain.stock.CreateStock;
import com.iiht.project.subham.ms1.iiht_ms1.domain.stock.StockCommandsHandler;

@RestController
@RequestMapping(value = "/api/v1.0/market/stock/")
public class StockController {
	@Autowired
	private StockCommandsHandler stockCommandsHandler;
	@PostMapping("/add/{companyCode}")
	public ResponseEntity<ResponseMessage> addCompany(@RequestBody CreateStock createStock,
			@PathVariable("companyCode") String companyCode) {
		return stockCommandsHandler.handleRequest(createStock, companyCode);
		
	}

}
