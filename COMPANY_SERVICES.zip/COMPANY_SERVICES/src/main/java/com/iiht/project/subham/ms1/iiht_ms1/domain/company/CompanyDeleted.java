package com.iiht.project.subham.ms1.iiht_ms1.domain.company;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class CompanyDeleted {
	private String companyCode;

}
