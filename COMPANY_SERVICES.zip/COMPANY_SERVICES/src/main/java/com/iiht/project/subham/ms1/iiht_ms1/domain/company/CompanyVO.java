package com.iiht.project.subham.ms1.iiht_ms1.domain.company;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class CompanyVO {
	private String companyCode;
	private String companyName;
	private String companyCEO;
	private String companyURL;
	private long companyTurnOver;
	private String stockExchange;
}
