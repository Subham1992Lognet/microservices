package com.iiht.project.subham.ms1.iiht_ms1.domain.stock;


import java.util.Date;



import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class StockPriceAdded {
	
	private Double stockPrice;
	private String companyCode;
	private Date stockCreatedDate;

}
