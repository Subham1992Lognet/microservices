package com.iiht.project.subham.ms1.iiht_ms1.domain.stock;

import java.util.Date;
import java.util.Random;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.iiht.project.subham.ms1.iiht_ms1.domain.company.CompanyCreated;
import com.iiht.project.subham.ms1.iiht_ms1.domain.company.CompanyVO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Document
@NoArgsConstructor
public class Stock {
	@Id
	private Long id;
	private StockPriceAdded stockPriceAdded;
	private String eventName;

	public Stock(StockPriceAdded stockPriceAddedEvent) {
		this.stockPriceAdded = stockPriceAddedEvent;
		this.eventName = stockPriceAddedEvent.getClass().getSimpleName();
		Random rnd = new Random();
	    char [] digits = new char[11];
	    digits[0] = (char) (rnd.nextInt(9) + '1');
	    for(int i=1; i<digits.length; i++) {
	        digits[i] = (char) (rnd.nextInt(10) + '0');
	    }
	    this.id = Long.parseLong(new String(digits));
	}

}
