/**
 * 
 */
package com.iiht.project.subham.ms1.iiht_ms1.domain.company;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.iiht.project.subham.ms1.iiht_ms1.domain.stock.StockPriceAdded;
import com.iiht.project.subham.ms1.iiht_ms1.utility.DomainUtility;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author User
 *
 */
@Setter
@Getter
@Document
@NoArgsConstructor
public class Company {
	@Id
	private String id;
	private String companyCode;
	private CompanyCreated companyCreated;
	private String eventName;
	private Date occuredOn;
	private CompanyDeleted companyDeleted;
	

	public Company(CompanyVO companyVO) {
		CompanyCreated companyCreatedEvent = CompanyCreated.builder().companyVO(companyVO).build();
		this.companyCode = companyVO.getCompanyCode();
		this.companyCreated = companyCreatedEvent;
		this.eventName = companyCreatedEvent.getClass().getSimpleName();
		//Date newDate =DomainUtility.GetUTSDate();		
		this.occuredOn = new Date();
	}


	public Company(String companyCode2) {
		CompanyDeleted deleted = CompanyDeleted.builder().companyCode(companyCode2).build();
		this.companyCode = companyCode2;
		this.companyDeleted = deleted;
		this.eventName = deleted.getClass().getSimpleName();
		this.occuredOn = new Date();
	}

}
