package com.iiht.project.subham.ms1.iiht_ms1.domain.stock;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CreateStock {
	
	private Double stockPrice;

}
