package com.iiht.project.subham.ms1.iiht_ms1.config;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.project.subham.ms1.iiht_ms1.domain.company.CompanyCommandsHandler;
import com.iiht.project.subham.ms1.iiht_ms1.domain.company.CreateCompany;
import com.iiht.project.subham.ms1.iiht_ms1.domain.model.CreateCompanyResponse;
import com.iiht.project.subham.ms1.iiht_ms1.domain.model.ResponseMessage;


@RestController
@RequestMapping(value = "/api/v1.0/market/company/")
public class CompanyController {
	
	@Autowired
	private CompanyCommandsHandler companyCommandsHandler; 
	
	@PostMapping("/register")
	public ResponseEntity<CreateCompanyResponse> addCompany(@Valid @RequestBody CreateCompany createCompany) {
		return companyCommandsHandler.handleRequest(createCompany);
		
	}
	
	@DeleteMapping("/delete/{companyCode}")
	public ResponseEntity<ResponseMessage> deleteCompany(@PathVariable("companyCode") String companyCode) {
			return companyCommandsHandler.deleteCompany(companyCode);
			
	}

}
