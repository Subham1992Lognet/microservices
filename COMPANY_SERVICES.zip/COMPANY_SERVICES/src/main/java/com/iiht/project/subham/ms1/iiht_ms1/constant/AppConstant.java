package com.iiht.project.subham.ms1.iiht_ms1.constant;

public class AppConstant {
	 public static final String TOPIC_NAME_1 = "test-1";
	 public static final String GROUP_ID = "group_id";
	 public static final String TOPIC_NAME_2 = "test-2";
}
