package com.iiht.project.subham.ms1.iiht_ms1.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CompanyDto {
	
	@JsonProperty("companyCode")
	private String companyCode;
	@JsonProperty("companyName")
	private String companyName;
	@JsonProperty("companyCEO")
	private String companyCEO;
	@JsonProperty("companyURL")
	private String companyURL;
	@JsonProperty("companyTurnOver")
	private double companyTurnOver;
	@JsonProperty("stockExchange")
	private String stockExchange;
	@Override
	public String toString() {
		return "CompanyDto [companyCode=" + companyCode + ", companyName=" + companyName + ", companyCEO=" + companyCEO
				+ ", companyURL=" + companyURL + ", companyTurnOver=" + companyTurnOver + ", stockExchange="
				+ stockExchange + "]";
	}
	
	

}
