package com.iiht.project.subham.ms1.iiht_ms1.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.iiht.project.subham.ms1.iiht_ms1.domain.company.CompanyVO;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder

public class CreateCompanyResponse {
	
	@JsonProperty("companyReponse")
	private CompanyVO companyVO;

}
