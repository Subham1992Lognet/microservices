package com.iiht.project.subham.ms1.iiht_ms1.config;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.iiht.project.subham.ms1.iiht_ms1.domain.stock.Stock;
@Repository
public interface StockRepository extends MongoRepository<Stock, Long> {

}
