package com.iiht.project.subham.ms1.iiht_ms1.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.iiht.project.subham.ms1.iiht_ms1.constant.AppConstant;

@Service
public class KafkaProducer
{     
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;
    private static final Logger LOG = LoggerFactory.getLogger(KafkaProducer.class);
 
    public void sendCustomerMessage(String message) 
    {
    	LOG.info("Message is  " + message);
       
       this.kafkaTemplate.send(AppConstant.TOPIC_NAME_1, message);
    }
    
    public void sendStockMessage(String message) 
    {
    	LOG.info("Message stock is " +  message);
       
       this.kafkaTemplate.send(AppConstant.TOPIC_NAME_2, message);
    }
}