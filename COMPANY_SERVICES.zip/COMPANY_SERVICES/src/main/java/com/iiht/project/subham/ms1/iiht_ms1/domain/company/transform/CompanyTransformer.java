package com.iiht.project.subham.ms1.iiht_ms1.domain.company.transform;



import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.iiht.project.subham.ms1.iiht_ms1.domain.company.CompanyVO;
import com.iiht.project.subham.ms1.iiht_ms1.domain.company.CreateCompany;

@Component
public class CompanyTransformer {

	public CompanyVO transform(CreateCompany createCompany) {
		String companyCode = null;
		if(StringUtils.isEmpty(createCompany.getCompanyCode())) {
			Random rnd = new Random();
		    char [] digits = new char[11];
		    digits[0] = (char) (rnd.nextInt(9) + '1');
		    for(int i=1; i<digits.length; i++) {
		        digits[i] = (char) (rnd.nextInt(10) + '0');
		    }
			companyCode = String.valueOf(Long.parseLong(new String(digits)));
		} else {
			companyCode = createCompany.getCompanyCode();
		}
		CompanyVO companyVO = CompanyVO.builder().companyCEO(createCompany.getCompanyCEO())
				.companyCode(companyCode)
				.companyName(createCompany.getCompanyName())
				.companyTurnOver(createCompany.getCompanyTurnOver())
				.companyURL(createCompany.getCompanyURL())
				.stockExchange(createCompany.getStockExchange()).build();
		
		return companyVO;
	}

}
