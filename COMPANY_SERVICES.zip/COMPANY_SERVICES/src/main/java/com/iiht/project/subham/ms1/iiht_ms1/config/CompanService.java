package com.iiht.project.subham.ms1.iiht_ms1.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class CompanService {
	@Autowired
	private CompanyRepository companyRepository;
	
	/*
	 * public ResponseEntity<CompanyResponse> getAllCompanyDetails() {
	 * 
	 * }
	 */

}
