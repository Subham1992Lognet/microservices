/**
 * 
 */
package com.iiht.project.subham.ms1.iiht_ms1.domain.company;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.UniqueElements;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


/**
 * @author User
 *
 */
@Setter
@Getter
@AllArgsConstructor
public class CreateCompany {	
	
	
	private String companyCode;
	@NotNull(message = "company Name is mandatory")
	private String companyName;
	@NotNull(message = "company CEO name is mandatory")
	private String companyCEO;
	@NotNull(message = "company URL is mandatory")
	private String companyURL;
	@NotNull(message = "company turn over is mandatory")
	@Min(value=100000000, message = "turn over will be greater than 10 cr")
	private Long companyTurnOver;
	@NotNull(message = "stock exchange is mandatory")
	private String stockExchange;


	@Override
	public String toString() {
		return "CreateCompany [companyCode=" + companyCode + ", companyName=" + companyName + ", companyCEO="
				+ companyCEO + ", companyURL=" + companyURL + ", companyTurnOver=" + companyTurnOver
				+ ", stockExchange=" + stockExchange + "]";
	}

	

}
