package com.iiht.project.subham.ms1.iiht_ms1.domain.stock;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.iiht.project.subham.ms1.iiht_ms1.config.CompanyRepository;
import com.iiht.project.subham.ms1.iiht_ms1.config.KafkaProducer;
import com.iiht.project.subham.ms1.iiht_ms1.config.StockRepository;
import com.iiht.project.subham.ms1.iiht_ms1.domain.company.CompanyCommandsHandler;
import com.iiht.project.subham.ms1.iiht_ms1.domain.model.ResponseMessage;
import com.iiht.project.subham.ms1.iiht_ms1.utility.DomainUtility;
@Component
public class StockCommandsHandler {
	
	@Autowired
	private CompanyRepository companyRepository;
	@Autowired
	private StockRepository stockRepository;
	@Autowired
	private KafkaProducer kafkaProducer;
	
	private static final Logger LOG = LoggerFactory.getLogger(StockCommandsHandler.class);

	public ResponseEntity<ResponseMessage> handleRequest(CreateStock createStock, String companyCode) {
		if(companyRepository.findByCompanyCode(companyCode).isPresent()) {
			StockPriceAdded stockPriceAdded = StockPriceAdded.builder().companyCode(companyCode)
					.stockPrice(createStock.getStockPrice()).stockCreatedDate(new Date()).build();
			Stock stock = new Stock(stockPriceAdded);
			Stock stockFromDb = stockRepository.save(stock);
			String message = null;
			ObjectMapper mapper = new ObjectMapper().registerModule(new JavaTimeModule())
					.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
			try {
				message = mapper.writeValueAsString(stockFromDb);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				LOG.error("Error is " , e.getMessage());
			}
			kafkaProducer.sendStockMessage(message);
			ResponseMessage responseMessage = ResponseMessage.builder().message("Stock Is Added").build();
			return new ResponseEntity<ResponseMessage>(responseMessage, HttpStatus.CREATED);
			
		} else {
			ResponseMessage responseMessage = ResponseMessage.builder().message("Company Code is not found").build();
			return new ResponseEntity<ResponseMessage>(responseMessage, HttpStatus.NOT_FOUND);
		}
		
	}

}
