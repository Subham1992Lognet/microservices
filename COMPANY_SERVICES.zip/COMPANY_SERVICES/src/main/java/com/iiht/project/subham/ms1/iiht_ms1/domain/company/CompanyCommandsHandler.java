/**
 * 
 */
package com.iiht.project.subham.ms1.iiht_ms1.domain.company;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.iiht.project.subham.ms1.iiht_ms1.config.CompanyRepository;
import com.iiht.project.subham.ms1.iiht_ms1.config.KafkaProducer;
import com.iiht.project.subham.ms1.iiht_ms1.domain.company.transform.CompanyTransformer;
import com.iiht.project.subham.ms1.iiht_ms1.domain.model.CreateCompanyResponse;
import com.iiht.project.subham.ms1.iiht_ms1.domain.model.ResponseMessage;

/**
 * @author User
 *
 */
@Component
public class CompanyCommandsHandler{
	@Autowired
	private CompanyTransformer companyTransformer;
	@Autowired
	private CompanyRepository companyRepository;
	@Autowired
	private KafkaProducer kafkaProducer;
	private static final Logger LOG = LoggerFactory.getLogger(CompanyCommandsHandler.class);
	
	
	public ResponseEntity<CreateCompanyResponse> handleRequest(CreateCompany createCompany) {
		LOG.info("Create Company object is " + createCompany);
		CompanyVO companyVO = companyTransformer.transform(createCompany);
		Company company = new Company(companyVO);
		Company companyFromDb = companyRepository.save(company);
		String message = null;
		try {
			message = new ObjectMapper().writeValueAsString(companyFromDb);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			LOG.error("Error message is ",  e.getMessage());
		}
		kafkaProducer.sendCustomerMessage(message);
		
		CreateCompanyResponse companyResponse = CreateCompanyResponse.builder()
				.companyVO(companyFromDb.getCompanyCreated().getCompanyVO()).build();
		
		return new ResponseEntity<CreateCompanyResponse>(companyResponse, HttpStatus.CREATED);		
		
	}


	public ResponseEntity<ResponseMessage> deleteCompany(String companyCode) {
		Company company = new Company(companyCode);
		Company companyFromDb = companyRepository.save(company);
		String message = null;
		try {
			message = new ObjectMapper().writeValueAsString(companyFromDb);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		kafkaProducer.sendCustomerMessage(message);
		
		ResponseMessage responseMessage = ResponseMessage.builder().message(companyCode + "Is Deleted").build();
		return new ResponseEntity<ResponseMessage>(responseMessage, HttpStatus.CREATED);		
		
	}

}
