package com.iiht.project.subham.kakfa.consumer1.domain.company;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;

import com.iiht.project.subham.kakfa.consumer1.domain.stock.StockReponseDetails;
import com.iiht.project.subham.kakfa.consumer1.model.CompanyDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompanyResponseDetails {
	
	private String companyCode;
	private String companyName;
	private String companyCEO;
	private String companyURL;
	private long companyTurnOver;
	private String stockExchange;
	private Date createdOn;
	private StockReponseDetails stockResponseDetails;

}
