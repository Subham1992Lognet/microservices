package com.iiht.project.subham.kakfa.consumer1.config;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.iiht.project.subham.kakfa.consumer1.model.StockDetails;

public interface StockRepository extends JpaRepository<StockDetails, Long> {
	@Transactional
	void deleteByCompanyCode(String companyCode);
	
	@Query(value = "Select s.* FROM stock_details s WHERE s.company_Code = ?1 order by 1 desc limit 1", nativeQuery = true)
	StockDetails findByCompanyCode(String companyCode);
	
	@Query("Select s FROM StockDetails s WHERE s.stockCreatedDate between ?2 and ?3 and "
			+ "s.companyCode = ?1")
	List<StockDetails> findBydateRange(String code, Date startDate, Date endDate);
}
