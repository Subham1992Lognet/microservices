package com.iiht.project.subham.kakfa.consumer1.domain.company;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompanyVO {
	private String companyCode;
	private String companyName;
	private String companyCEO;
	private String companyURL;
	private long companyTurnOver;
	private String stockExchange;
}
