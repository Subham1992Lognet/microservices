package com.iiht.project.subham.kakfa.consumer1.domain.stock;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;



import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StockPriceAdded {
	private Double stockPrice;
	private String companyCode;
	private Date stockCreatedDate;

}
