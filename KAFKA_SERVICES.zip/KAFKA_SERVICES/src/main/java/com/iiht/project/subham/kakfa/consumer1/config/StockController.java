package com.iiht.project.subham.kakfa.consumer1.config;

import java.time.OffsetDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.project.subham.kakfa.consumer1.domain.stock.StockReponseDetails;
import com.iiht.project.subham.kakfa.consumer1.domain.stock.StockService;

@RestController
@RequestMapping(value = "/api/v1.0/market/stock/")
public class StockController {
	
	@Autowired
	private StockService service;
	
	@GetMapping("get/{companyCode}/{startDate}/{endDate}")
	public ResponseEntity<List<StockReponseDetails>> getStockDetails(@PathVariable("companyCode") String companyCode,
			@PathVariable("startDate") String startDate,
			@PathVariable("endDate") String endDate){
		
		return service.getStockDetails(companyCode, startDate, endDate);
	}
}
