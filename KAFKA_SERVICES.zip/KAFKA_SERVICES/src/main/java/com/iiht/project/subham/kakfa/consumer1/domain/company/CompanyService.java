package com.iiht.project.subham.kakfa.consumer1.domain.company;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.iiht.project.subham.kakfa.consumer1.config.CompanyRepository;
import com.iiht.project.subham.kakfa.consumer1.config.StockRepository;
import com.iiht.project.subham.kakfa.consumer1.domain.stock.StockReponseDetails;
import com.iiht.project.subham.kakfa.consumer1.domain.stock.StockService;
import com.iiht.project.subham.kakfa.consumer1.model.CompanyDetails;
import com.iiht.project.subham.kakfa.consumer1.model.StockDetails;

@Service
public class CompanyService {
	
	@Autowired
	private CompanyRepository companyRepository;
	@Autowired
	private StockRepository stockRepository;
	
	private static final Logger LOG = LoggerFactory.getLogger(CompanyService.class);
	
	

	public ResponseEntity<List<CompanyResponseDetails>> getCompanyDetails() {
		List<CompanyDetails> companyDetails = companyRepository.findAll();
		List<CompanyResponseDetails> companyResponseDetailsList = new ArrayList<CompanyResponseDetails>();;
		CompanyResponseDetails companyResponseDetails = null;
		LOG.info("companyDetails is " + companyDetails);
		for(CompanyDetails companyDetails2 : companyDetails) {
			companyResponseDetails = new CompanyResponseDetails();
			companyResponseDetails.setCompanyCEO(companyDetails2.getCompanyCEO());
			companyResponseDetails.setCompanyCode(companyDetails2.getCompanyCode());
			companyResponseDetails.setCompanyName(companyDetails2.getCompanyName());
			companyResponseDetails.setCompanyTurnOver(companyDetails2.getCompanyTurnOver());
			companyResponseDetails.setCompanyURL(companyDetails2.getCompanyURL());
			companyResponseDetails.setStockExchange(companyDetails2.getStockExchange());
			LOG.info("company code  is " + companyDetails2.getCompanyCode());			
			companyResponseDetails.setStockResponseDetails(
			(createStockResponse(stockRepository.findByCompanyCode(companyDetails2.getCompanyCode()))));
			companyResponseDetails.setCreatedOn(companyDetails2.getCreatedOn());
			companyResponseDetailsList.add(companyResponseDetails);
		}
		return new ResponseEntity<List<CompanyResponseDetails>>(companyResponseDetailsList, HttpStatus.OK);
	}


	private StockReponseDetails createStockResponse(StockDetails stockDetails) {
		LOG.info("stockDetails is " + stockDetails);
		StockReponseDetails reponseDetails = null;
		
			reponseDetails = new StockReponseDetails();
			reponseDetails.setStockPrice(stockDetails.getStockPrice());
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String date = dateFormat.format(stockDetails.getStockCreatedDate());
			DateTimeFormatter formatter =
		            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.US);
	         
			LocalDateTime localDateTime = LocalDateTime.parse(date, formatter);
	        LocalTime localTime = localDateTime.toLocalTime();
	        LocalDate localDate = LocalDate.parse(date, formatter);
	        reponseDetails.setStockCreatedDate(localDate);
	        reponseDetails.setStockCreatedTime(localTime);
					
		
		return reponseDetails;
	}


	public ResponseEntity<CompanyResponseDetails> getCompanyInfo(String companyCode) {
		CompanyDetails companyDetails2 = companyRepository.findByCompanyCode(companyCode);
		CompanyResponseDetails companyResponseDetails = null;
		companyResponseDetails = new CompanyResponseDetails();
		companyResponseDetails.setCompanyCEO(companyDetails2.getCompanyCEO());
		companyResponseDetails.setCompanyCode(companyDetails2.getCompanyCode());
		companyResponseDetails.setCompanyName(companyDetails2.getCompanyName());
		companyResponseDetails.setCompanyTurnOver(companyDetails2.getCompanyTurnOver());
		companyResponseDetails.setCompanyURL(companyDetails2.getCompanyURL());
		companyResponseDetails.setStockExchange(companyDetails2.getStockExchange());
		LOG.info("company code  is " + companyDetails2.getCompanyCode());	
		companyResponseDetails.setStockResponseDetails(
		(createStockResponse(stockRepository.findByCompanyCode(companyDetails2.getCompanyCode()))));
		companyResponseDetails.setCreatedOn(companyDetails2.getCreatedOn());
	
		return new ResponseEntity<CompanyResponseDetails>(companyResponseDetails, HttpStatus.OK);
		
		
	}

}
