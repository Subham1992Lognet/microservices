package com.iiht.project.subham.kakfa.consumer1.domain.stock;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import com.iiht.project.subham.kakfa.consumer1.model.StockDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StockReponseDetails {
	
	private Double stockPrice;
	private LocalDate stockCreatedDate;
	private LocalTime stockCreatedTime;

}
