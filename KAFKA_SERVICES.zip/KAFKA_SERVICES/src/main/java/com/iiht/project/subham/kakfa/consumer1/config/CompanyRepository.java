package com.iiht.project.subham.kakfa.consumer1.config;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iiht.project.subham.kakfa.consumer1.model.CompanyDetails;
import com.iiht.project.subham.kakfa.consumer1.model.StockDetails;
@Repository
public interface CompanyRepository extends JpaRepository<CompanyDetails, Long> {
	CompanyDetails findByCompanyCode(String companyCode);
	@Transactional
	void deleteByCompanyCode(String companyCode);

}
