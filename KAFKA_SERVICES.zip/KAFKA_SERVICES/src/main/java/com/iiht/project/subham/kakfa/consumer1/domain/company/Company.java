package com.iiht.project.subham.kakfa.consumer1.domain.company;

import java.util.Date;

import com.iiht.project.subham.kakfa.consumer1.domain.Base;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Company extends Base{
	
	private CompanyCreated companyCreated;
	private CompanyDeleted companyDeleted;
	


}
