package com.iiht.project.subham.kakfa.consumer1.domain.stock;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.iiht.project.subham.kakfa.consumer1.config.StockRepository;
import com.iiht.project.subham.kakfa.consumer1.model.StockDetails;

@Service
public class StockService {
	@Autowired
	private StockRepository repository;
	private static final Logger LOG = LoggerFactory.getLogger(StockService.class);
	

	public ResponseEntity<List<StockReponseDetails>> getStockDetails(String companyCode, String startDate, String endDate) {
		Date sDate = null;
		Date eDate = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
		dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		try {
			sDate = dateFormat.parse(startDate);
			eDate = dateFormat.parse(endDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			LOG.error("Json PArsing error ", e.getMessage());
		}
		System.out.println(companyCode + " " + sDate + " "+eDate);
		LOG.info("company Code ", companyCode);
		LOG.info("start Date ", sDate);
		LOG.info("end Date ", eDate);
		List<StockDetails> details =  repository.findBydateRange(companyCode, sDate, eDate);
		List<StockReponseDetails> reponseDetails = new ArrayList<StockReponseDetails>();
		StockReponseDetails stockReponseDetails = null;
		for(StockDetails details2 : details) {
			stockReponseDetails = new StockReponseDetails();
			stockReponseDetails.setStockPrice(details2.getStockPrice());
			SimpleDateFormat dateFormatSecond = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			dateFormatSecond.setTimeZone(TimeZone.getTimeZone("UTC"));
			String date = dateFormatSecond.format(details2.getStockCreatedDate());
			DateTimeFormatter formatter =
		            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	        
			LocalDateTime localDateTime = LocalDateTime.parse(date, formatter);
	        LocalTime localTime = localDateTime.toLocalTime();
	        LocalDate localDate = LocalDate.parse(date, formatter);
			stockReponseDetails.setStockCreatedDate(localDate);
			stockReponseDetails.setStockCreatedTime(localTime);
			reponseDetails.add(stockReponseDetails);
		}
		
		return new ResponseEntity<List<StockReponseDetails>>(reponseDetails, HttpStatus.OK);
		
	}

}
