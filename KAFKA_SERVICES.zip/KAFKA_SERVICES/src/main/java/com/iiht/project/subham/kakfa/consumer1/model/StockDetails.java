package com.iiht.project.subham.kakfa.consumer1.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "StockDetails")
public class StockDetails {
	@Id
	@Column(name = "STOCK_ID")
	private Long id;
	@Column(name = "STOCK_PRICE")
	private Double stockPrice;
	@Column(name = "COMPANY_CODE")
	private String companyCode;
	@Column(name = "STOCK_CREATED_DATE")
	private Date stockCreatedDate;

}
