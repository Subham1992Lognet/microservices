package com.iiht.project.subham.kakfa.consumer1.constant;

public class AppConstant {
	public static final String TOPIC_NAME_1 = "test-1";
	 public static final String GROUP_ID = "group_id";
	 public static final String TOPIC_NAME_2 = "test-2";
	 public static final String TOPIC_NAME_3 = "test3";
}
