package com.iiht.project.subham.kakfa.consumer1.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "CompanyDetails")
public class CompanyDetails {
	@Id
	@Column(name = "COMPANY_CODE")
	private String companyCode;
	@Column(name = "COMPANY_NAME")
	private String companyName;
	@Column(name = "COMPANY_CEO")
	private String companyCEO;
	@Column(name = "COMPANY_URL")
	private String companyURL;
	@Column(name = "COMPANY_TO")
	private long companyTurnOver;
	@Column(name = "COMPANY_SE")
	private String stockExchange;
	@Column(name = "COMPANY_CREATED_DATE")
	private Date createdOn;

}
