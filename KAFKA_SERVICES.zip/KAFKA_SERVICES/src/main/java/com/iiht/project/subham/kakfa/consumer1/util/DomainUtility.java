package com.iiht.project.subham.kakfa.consumer1.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DomainUtility {
	public static Date getUTSDate() {
		Date date = new Date();
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",  Locale.US);
		String parsedDate = dateFormat1.format(date);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
		//dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date newDate = null;
		try {
			newDate = dateFormat.parse(parsedDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newDate;
	}

}
