package com.iiht.project.subham.kakfa.consumer1.domain.stock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.iiht.project.subham.kakfa.consumer1.config.StockRepository;
import com.iiht.project.subham.kakfa.consumer1.model.StockDetails;
import com.iiht.project.subham.kakfa.consumer1.util.DomainUtility;

@Component
public class StockSubscriberHandler {
	
	@Autowired
	private StockRepository stockRepository;
	private static final Logger LOG = LoggerFactory.getLogger(StockSubscriberHandler.class);
	
	
	public void subscribe(String message) {
		ObjectMapper mapper = new ObjectMapper().registerModule(new JavaTimeModule())
				.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			Stock stock = mapper.readValue(message, Stock.class);
			StockDetails stockDetails = StockDetails.builder().stockPrice(stock.getStockPriceAdded().getStockPrice())
					.id(stock.getId())
				.companyCode(stock.getStockPriceAdded().getCompanyCode())
				.stockCreatedDate(DomainUtility.getUTSDate()).build();
			stockRepository.save(stockDetails);
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			LOG.error("Json Mapping Exception ", e.getMessage());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			LOG.error("Json Parsing Exception ", e.getMessage());
		}
		
	}
	

}
