package com.iiht.project.subham.kakfa.consumer1.domain.stock;

import java.util.Date;

import org.springframework.data.annotation.Id;

import com.iiht.project.subham.kakfa.consumer1.domain.Base;
import com.iiht.project.subham.kakfa.consumer1.domain.company.CompanyCreated;
import com.iiht.project.subham.kakfa.consumer1.domain.company.CompanyVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Stock {	
	private StockPriceAdded stockPriceAdded;
	private String eventName;
	private Date occuredOn;
	private Long id;

}
