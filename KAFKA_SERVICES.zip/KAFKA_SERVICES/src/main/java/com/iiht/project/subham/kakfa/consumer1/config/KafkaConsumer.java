package com.iiht.project.subham.kakfa.consumer1.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.iiht.project.subham.kakfa.consumer1.constant.AppConstant;
import com.iiht.project.subham.kakfa.consumer1.domain.company.CompanySubscriberHandler;
import com.iiht.project.subham.kakfa.consumer1.domain.stock.StockSubscriberHandler;

@Service
public class KafkaConsumer{
	@Autowired
	private CompanySubscriberHandler compnaySubscriberHandler;
	@Autowired
	private StockSubscriberHandler stockSubscriberHandler;
	
	@KafkaListener(topics = AppConstant.TOPIC_NAME_1, 
            groupId = AppConstant.GROUP_ID)
    public void consumeCompany(String message) 
    {
        System.out.println(String.format("Message recieved -> %s", message));
        compnaySubscriberHandler.subscribe(message);
    }
	
	@KafkaListener(topics = AppConstant.TOPIC_NAME_2, 
            groupId = AppConstant.GROUP_ID)
    public void consumeStock(String message) 
    {
        System.out.println(String.format("Message recieved -> %s", message));
        stockSubscriberHandler.subscribe(message);
    }


}