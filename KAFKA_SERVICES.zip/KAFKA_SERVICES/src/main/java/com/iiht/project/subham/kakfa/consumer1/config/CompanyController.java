package com.iiht.project.subham.kakfa.consumer1.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.project.subham.kakfa.consumer1.domain.company.CompanyResponseDetails;
import com.iiht.project.subham.kakfa.consumer1.domain.company.CompanyService;

@RestController
@RequestMapping(value = "/api/v1.0/market/company/")
public class CompanyController {
	
	 @Autowired 
	 private CompanyService companyService;
	 
	 @GetMapping("/getAll")
	 public ResponseEntity<List<CompanyResponseDetails>> getCompanyDetails() {
			return companyService.getCompanyDetails();
			
	 }
	 @GetMapping("/info/{companyCode}")
	 public ResponseEntity<CompanyResponseDetails> getCompanyInfo(@PathVariable("companyCode") String companyCode) {
			return companyService.getCompanyInfo(companyCode);
			
	 }
}
