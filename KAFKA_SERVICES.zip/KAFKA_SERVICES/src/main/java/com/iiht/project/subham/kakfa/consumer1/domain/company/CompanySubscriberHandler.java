package com.iiht.project.subham.kakfa.consumer1.domain.company;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.iiht.project.subham.kakfa.consumer1.config.CompanyRepository;
import com.iiht.project.subham.kakfa.consumer1.config.StockRepository;
import com.iiht.project.subham.kakfa.consumer1.domain.Base;
import com.iiht.project.subham.kakfa.consumer1.domain.stock.Stock;
import com.iiht.project.subham.kakfa.consumer1.domain.stock.StockSubscriberHandler;
import com.iiht.project.subham.kakfa.consumer1.model.CompanyDetails;
import com.iiht.project.subham.kakfa.consumer1.model.StockDetails;
import com.iiht.project.subham.kakfa.consumer1.util.DomainUtility;

@Component
public class CompanySubscriberHandler {
	@Autowired
	private CompanyRepository companyRepository;
	@Autowired
	private StockRepository stockRepository;;
	private static final Logger LOG = LoggerFactory.getLogger(CompanySubscriberHandler.class);
	

	public void subscribe(String message) {
		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			Company company = mapper.readValue(message, Company.class);
			if(company.getCompanyCreated() != null) {
				CompanyDetails companyDetails = CompanyDetails.builder()
							.companyCEO(company.getCompanyCreated().getCompanyVO().getCompanyCEO())
							.companyCode(company.getCompanyCreated().getCompanyVO().getCompanyCode())
							.companyName(company.getCompanyCreated().getCompanyVO().getCompanyName())
							.companyTurnOver(company.getCompanyCreated().getCompanyVO().getCompanyTurnOver())
							.companyURL(company.getCompanyCreated().getCompanyVO().getCompanyURL())
							.stockExchange(company.getCompanyCreated().getCompanyVO().getStockExchange())
							.createdOn(DomainUtility.getUTSDate()).build();
				companyRepository.save(companyDetails);
			} else if (company.getCompanyDeleted() != null ) {
				companyRepository.deleteByCompanyCode(company.getCompanyDeleted().getCompanyCode());
				stockRepository.deleteByCompanyCode(company.getCompanyDeleted().getCompanyCode());
			}
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			LOG.error("Json Mapping Exception ", e.getMessage());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			LOG.error("Json Parsing Exception ", e.getMessage());
		}
		
		
	}

}
