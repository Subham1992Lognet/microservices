package com.lambda;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public class LambdaHandler implements RequestHandler<Map<String, Object>, ApiGatewayProxyResponse> {

	
	private static final Logger logger = LoggerFactory.getLogger(LambdaHandler.class);

	
	 @Override 
	 public ApiGatewayProxyResponse  handleRequest(Map<String, Object> input, Context context) {
		 Map<String, String> APPLICATION_JSON = new HashMap<>();
		 APPLICATION_JSON.put("Content-Type", "application/json");
		 APPLICATION_JSON.put("Access-Control-Allow-Origin","*");
		 APPLICATION_JSON.put("Access-Control-Allow-Headers","Origin, X-Requested-With, Content-Type, Accept, Authorization");
		 APPLICATION_JSON.put("Access-Control-Allow-Credentials","true");
		 APPLICATION_JSON.put("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD");
		 
		 logger.info("Loading Java Lambda handler of ProxyWithStream");
		 logger.info("input is "+ input);
		 ObjectMapper objectMapper = new ObjectMapper();
		 objectMapper.registerModule(new JavaTimeModule());
	     objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	     objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
	     
		 String resource = (String) input.get("resource");
		 String url = "jdbc:mysql://companydatabase.cluster-csb0oyhrbn4d.us-east-2.rds.amazonaws.com:3306/readModel";
		 String username = "subham";
	     String password = "Database123";
	     try {
		     Connection conn = DriverManager.getConnection(url, username, password);
		     Statement stmt = conn.createStatement();
			 if(resource.contains("getcompanydetails")) {
				  Map pathParams = (Map) input.get("pathParameters");
			      String query = "SELECT * from company_details where company_code = '" +(String)pathParams.get("companyCode")+"'";
			      logger.info(query);
			      ResultSet resultSet = stmt.executeQuery(query);
			      CompanyResponse companyResponse = null; 
			      while(resultSet.next()){
			         logger.info("Customer code : " + resultSet.getString("company_code"));	          
			          
			 		 companyResponse= new CompanyResponse(); 
			 		 companyResponse.setCompanyCode((String)pathParams.get("companyCode"));
			 		 companyResponse.setCompanyName(resultSet.getString("company_name"));
			 		 companyResponse.setCompanyStockExchange(resultSet.getString("company_stockExchange"));
			 		 companyResponse.setCompanyTurnOver(resultSet.getInt("company_turnOver"));
			 		 companyResponse.setCompanyURL(resultSet.getString("company_url"));
			       }
			      //stmt = conn.createStatement();
			      String queryStock = "SELECT * from stock_details where company_code = '" +(String)pathParams.get("companyCode")+"'";
			      logger.info(queryStock);
			      resultSet = stmt.executeQuery(queryStock);
			      List<StocResponse> stockList = new ArrayList<StocResponse>();
			      StocResponse response = null;
			      while(resultSet.next()){
			    	  	logger.info("Customer code : " + resultSet.getString("company_code"));	          
				          
				         response= new StocResponse();
				         response.setStockPrice(resultSet.getDouble("stock_price"));
				         logger.info("Date is " + resultSet.getTimestamp("stock_date"));
				         response.setStockDate(resultSet.getTimestamp("stock_date"));
				         stockList.add(response);
				  }
			      companyResponse.setStockDetails(stockList);
			      
			      return new ApiGatewayProxyResponse(200, APPLICATION_JSON, objectMapper.writeValueAsString(companyResponse));
	
			 } else if(resource.contains("getstockdetails")) {
				 Map pathParams = (Map) input.get("pathParameters");
				 String companyCode = (String)pathParams.get("companyCode");
				 String startDate = (String)pathParams.get("startDate");
				 String endDate = (String)pathParams.get("endDate");
				 Date sDate = null;
				 Date eDate = null;
				 logger.info("Customer code : " + companyCode);	    
				 logger.info("startDate: " + startDate);	   
				 logger.info("endDate : " + endDate);	 
				 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
				 dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
				 SimpleDateFormat dateFormatToSQLString = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
				 try {
						sDate = dateFormat.parse(startDate);
						eDate = dateFormat.parse(endDate);
				 } catch (ParseException e) {
						// TODO Auto-generated catch block
						logger.error("Json PArsing error ", e.getMessage());
				 }
				 logger.info("start Date "+ sDate);
				 logger.info("end Date "+  eDate);
				 String queryStock = "SELECT * from stock_details where stock_date between '" + startDate + "' and '" + endDate + "' and company_code = '" +companyCode+ "'";
				 logger.info(queryStock);
			     ResultSet resultSet = stmt.executeQuery(queryStock);
			     List<StockDetailsResponse> stockList = new ArrayList<StockDetailsResponse>();
			     StockDetailsResponse response = null;
			     while(resultSet.next()){
			    	  	logger.info("Customer code : " + resultSet.getString("company_code"));	          
				          
				         response= new StockDetailsResponse();
				         response.setStockPrice(resultSet.getDouble("stock_price"));
				         
				         
				         Timestamp timestamp = resultSet.getTimestamp("stock_date");
				         Date now = timestamp;
				         SimpleDateFormat dateFormatSecond = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						 dateFormatSecond.setTimeZone(TimeZone.getTimeZone("UTC"));
					     String date = dateFormatSecond.format(now);
					     logger.info("Date is " + date);
						 DateTimeFormatter formatter =
						            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
					        
						 LocalDateTime localDateTime = LocalDateTime.parse(date, formatter);
					     LocalTime localTime = localDateTime.toLocalTime();
					     logger.info("localTime is " + localTime);
					     LocalDate localDate = LocalDate.parse(date, formatter);
					     logger.info("localDate is " + localDate);
					     response.setStockDate(localDate);
					     response.setStockTime(localTime);
				         stockList.add(response);
				 }
			     return new ApiGatewayProxyResponse(200, APPLICATION_JSON, objectMapper.writeValueAsString(stockList));
			 }

		    } catch (Exception e) {
		      e.printStackTrace();
		      logger.info("Caught exception: " + e.getMessage());
		    }
		
		 	return null;
		 
		 
		 
	 }


	
	 

}
