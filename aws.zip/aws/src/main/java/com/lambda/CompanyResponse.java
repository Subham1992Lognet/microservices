package com.lambda;

import java.util.List;

public class CompanyResponse {
	private String companyCode;
	private String companyName;
	private String companyURL;
	private String companyStockExchange;
	private double companyTurnOver;
	private List<StocResponse> stockDetails;
	
	public List<StocResponse> getStockDetails() {
		return stockDetails;
	}
	public void setStockDetails(List<StocResponse> stockDetails) {
		this.stockDetails = stockDetails;
	}
	public String getCompanyCode() {
		return companyCode;
	}
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyURL() {
		return companyURL;
	}
	public void setCompanyURL(String companyURL) {
		this.companyURL = companyURL;
	}
	public String getCompanyStockExchange() {
		return companyStockExchange;
	}
	public void setCompanyStockExchange(String companyStockExchange) {
		this.companyStockExchange = companyStockExchange;
	}
	public double getCompanyTurnOver() {
		return companyTurnOver;
	}
	public void setCompanyTurnOver(double companyTurnOver) {
		this.companyTurnOver = companyTurnOver;
	}
	
	

}
