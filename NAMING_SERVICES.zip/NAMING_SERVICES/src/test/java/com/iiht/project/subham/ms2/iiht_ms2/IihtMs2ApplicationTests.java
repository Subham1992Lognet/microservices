package com.iiht.project.subham.ms2.iiht_ms2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IihtMs2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
