import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';  
import { Observable } from 'rxjs';  
import { Company } from './company';

@Injectable()
export class CompanyService {
  private usersUrl: string;

  constructor(private http: HttpClient) {
    this.usersUrl = ' https://ckdvkaq02a.execute-api.us-east-2.amazonaws.com/dev/api/getstockdetails';
  }

  public save(company: Company) {
    return this.http.post<Company>(this.usersUrl, company);
  }
  public listOfCompanies(name: String, startDate: Date, endDate:Date): Observable<Company[]> {
    /*const headers = new HttpHeaders()
    .set('token', 'eyJraWQiOiJxQ1dhOFwvWlVHRHZweExUZlFwa3pOUlNxYkJ0MzU4SVN5djZlb215dmw4az0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJiMGU1MjVjNy1jMGY1LTRhMTEtOGM0YS0xYmI1ZmExZjk0YjYiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMi5hbWF6b25hd3MuY29tXC91cy1lYXN0LTJfQnZkRm9qWXU2IiwiY29nbml0bzp1c2VybmFtZSI6ImIwZTUyNWM3LWMwZjUtNGExMS04YzRhLTFiYjVmYTFmOTRiNiIsIm9yaWdpbl9qdGkiOiJmY2E2MDc2Ni1mMzQxLTRmYzMtYTIzNC0xZjkyODYzZmU3Y2EiLCJhdWQiOiI1YThhM3JmNmk1NXU1bjY1NDJhcDdyMWlmMyIsImV2ZW50X2lkIjoiNzg4MWY1MzQtNDI4MS00MjYzLTlkNjMtYTE3NTllYjZmODU1IiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE2MjY0NDg2MTUsImV4cCI6MTYyNjQ1MjIxNSwiaWF0IjoxNjI2NDQ4NjE1LCJqdGkiOiIxYmQ1NDJkMy1hZjI3LTRhODAtODYzMi1hOTA0NjljNzI4NGQiLCJlbWFpbCI6InN1YmhhbWM1OTVAZ21haWwuY29tIn0.bagRp6cJkg1mIjZEs1yKnTryeo3d8vbzQwEPh2pqxHw9dp768cqb1cRo7H4OPMzNBEKpAxagz77KKVvj-HWYikr-gsUm5luRoXMRZZf8BAGxPpHgrbdDfXqFVCeH-phpGSDDtfAI-8Io3HbHEtkqx6519WFM7yYhzM2aEbxk29O5fAL94DxHZ1nqhrkoG0OYFD4fkFHtMrNjRQppzNY6nDWccPQg3iYkgHXiXaSMpSgI6WoaW2aMXYwaBEZuWVmE8L6mO9abmJ3_EmuiLQ6kIqJO_89Ef_lmmtrBweTxaPI1Khz_kF5svz43iT9UA3nyHcPeIK8ebjq_XX8xKKTPwg')
    .set('content-type', 'application/json')
    .set('sec-fetch-mode', 'cors')
    .set('sec-fetch-site', 'cross-site')
    .set('access-control-request-method', 'GET')
    .set('access-control-request-headers', 'content-type,token')
    .set('origin', 'http://localhost:4200')
    .set('access-control-request-method', 'GET');*/

    
    console.log("Entered Start Date : " + startDate);
    console.log("Entered End Date : " + endDate);
    console.log("Entered code : " + name);
    return this.http.get<Company[]>(this.usersUrl +'/' + name + '/' + startDate + '/' + endDate);  
  }  

}
