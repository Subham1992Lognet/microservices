import { Component, OnInit } from '@angular/core';
import { Company } from '../company';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements OnInit {
  companyName;
  startDate;
  endDate;
  max;
  min;
  avg;
  i;
  sum:number;
  
  stockPrices : number[]=[];
  companyList: Company[];

  constructor(private companyService: CompanyService) { }


  ngOnInit() {
  }

  onSubmit(data) {
    this.companyService.listOfCompanies(data.company_name, data.startDate, data.endDate).subscribe(data => {
      this.companyList = data;
      this.i=0;
      for(let company of this.companyList) {
       this.stockPrices[this.i] = company.stockPrice;
       this.i++;
      }
      this.min = Math.min.apply(Math, this.stockPrices);
      this.max = Math.max.apply(Math, this.stockPrices);
      console.log("Max : " + this.max);
      console.log("Min : " + this.min);
      this.sum = 0;
      for(let price of this.stockPrices) {
        this.sum = this.sum + price;
      }
      console.log("Sum : " + this.sum);
      this.avg = this.sum / this.stockPrices.length;
      console.log("Avg : " + this.avg);
    });
 }

}
