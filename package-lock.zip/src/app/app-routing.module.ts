import { NgModule } from '@angular/core';  
import { Routes, RouterModule } from '@angular/router';  
import { CompanyListComponent } from './company-list/company-list.component';  
import { AddCompanyComponent } from './add-company/add-company.component';  
  
const routes: Routes = [  
  { path: '', redirectTo: 'view-student', pathMatch: 'full' },  
  { path: 'view-company', component: CompanyListComponent },  
  { path: 'add-company', component: AddCompanyComponent },  
];  
  
@NgModule({  
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],  
  exports: [RouterModule]  
})  
export class AppRoutingModule { }  