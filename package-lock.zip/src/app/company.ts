export class Company {  
  
    stockPrice : number;
    stockCreatedDate : String;
    stockCreatedTime : String
}  