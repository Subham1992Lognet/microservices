import { Component, OnInit } from '@angular/core';
import { CompanyService } from '../company.service';  
import { Company } from '../company';  
import {FormControl,FormGroup,Validators} from '@angular/forms';  
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-company',
  templateUrl: './add-company.component.html',
  styleUrls: ['./add-company.component.css']
})
export class AddCompanyComponent implements OnInit {

  company: Company;

  constructor(
    private route: ActivatedRoute, 
      private router: Router, 
        private companyService: CompanyService) {
    this.company = new Company();
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  onSubmit() {
    this.companyService.save(this.company).subscribe(result => this.gotoUserList());
  }

  gotoUserList() {
    this.router.navigate(['/users']);
  }

}
